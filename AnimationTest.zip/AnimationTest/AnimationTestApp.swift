//
//  AnimationTestApp.swift
//  AnimationTest
//
//  Created by venrok on 07.11.2020.
//

import SwiftUI

@main
struct AnimationTestApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
